package com.example.cyntia.micuisine.actividades;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;
import com.example.cyntia.micuisine.R;
import com.example.cyntia.micuisine.modelo.Cantidad;
import com.example.cyntia.micuisine.modelo.Ingrediente;
import com.example.cyntia.micuisine.modelo.Receta;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.io.Serializable;
import java.util.ArrayList;

public class Ingredient extends AppCompatActivity {

    private FirebaseDatabase db;
    private Ingrediente nuevo;
    private Cantidad nueva;
    private ArrayList<String> listaIngredientesSpinner = new ArrayList<>();
    private ArrayList<String> listaIngredientesReceta = new ArrayList<>();
    private ArrayList<String> listaCantidadesSpinner = new ArrayList<>();
    private ArrayList<String> listaCantidadesReceta = new ArrayList<>();
    private String ingredienteSeleccionado;
    private String cantidadSeleccionada;
    private ListView listView,listCantidad;
    private Button guardar, guardar1,guardar2;
    private EditText nuevoIngrediente ,nuevaCantidad;
    private String key;
    private Boolean esta;
    private Boolean estas;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingredient);

        nuevoIngrediente = findViewById(R.id.nuevoIgrediente);
        nuevaCantidad = findViewById(R.id.nuevaCantidad);
        guardar1 = findViewById(R.id.nuevo);
        guardar2 = findViewById(R.id.nueva);
        nuevoIngrediente.setVisibility(View.INVISIBLE);
        guardar1.setVisibility(View.INVISIBLE);
        nuevaCantidad.setVisibility(View.INVISIBLE);
        guardar2.setVisibility(View.INVISIBLE);
        final Bundle mireceta = getIntent().getExtras();
        final Receta editar = (Receta) mireceta.getSerializable("receta");
        listaIngredientesReceta.addAll(editar.getListaIngredientes());
        listaCantidadesReceta.addAll(editar.getListaCantidades());
        listView = findViewById(R.id.listaIngredientes);
        listCantidad = findViewById(R.id.listaCantidad);
        db = FirebaseDatabase.getInstance();
        DatabaseReference ref = db.getReference("ingrediente");
        DatabaseReference referen = db.getReference("cantidad");

        //
        // Me traigo los ingredientes de la base de datos y los muestro en el spinner
        listaIngredientesSpinner.add("Ingredientes");
        listaCantidadesSpinner.add("Cantidad");

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                listaIngredientesSpinner.removeAll(listaIngredientesSpinner);
                if(!listaIngredientesSpinner.contains("Ingredientes")){
                    listaIngredientesSpinner.add("Ingredientes");
                }
                for (DataSnapshot dato : dataSnapshot.getChildren()) {
                    nuevo = dato.getValue(Ingrediente.class);
                    listaIngredientesSpinner.add(nuevo.getNombre());
                }
                if(!listaIngredientesSpinner.contains("Otro")){
                    listaIngredientesSpinner.add("Otro");
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) { }
        });
        //
        //Me traigo las cantidades de la base de datos para mostrarlas en el spinner
        referen.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                listaCantidadesSpinner.removeAll(listaCantidadesSpinner);
                if(!listaCantidadesSpinner.contains("Cantidad")){
                    listaCantidadesSpinner.add("Cantidad");
                }

                for (DataSnapshot dato : dataSnapshot.getChildren()) {
                    nueva = dato.getValue(Cantidad.class);
                    listaCantidadesSpinner.add(nueva.getPeso());
                }
                if(!listaCantidadesSpinner.contains("Otra")){
                    listaCantidadesSpinner.add("Otra");
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) { }
        });
        //
        //Adaptador para lista de cantidad
        final ArrayAdapter adaptadr = new ArrayAdapter(this, android.R.layout.simple_list_item_1, listaCantidadesReceta);
        listCantidad.setAdapter(adaptadr);
        Spinner cantida = (Spinner) findViewById(R.id.cantidad);
        cantida.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, listaCantidadesSpinner));
        cantida.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                cantidadSeleccionada = parent.getItemAtPosition(position).toString();
                if(!cantidadSeleccionada.equals("Cantidad")) {
                    if(cantidadSeleccionada.equals("Otra")){
                        nuevaCantidad.setVisibility(View.VISIBLE);
                        guardar2.setVisibility(View.VISIBLE);
                    }else{
                        listaCantidadesReceta.add(cantidadSeleccionada);
                        listCantidad.setAdapter(adaptadr);
                        adaptadr.notifyDataSetChanged();
                    }
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        //Adaptador para lista de los ingredientes
        final ArrayAdapter adaptador = new ArrayAdapter(this, android.R.layout.simple_list_item_1, listaIngredientesReceta);
        listView.setAdapter(adaptador);

        Spinner ingredient = (Spinner) findViewById(R.id.ingredientes);
        ingredient.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, listaIngredientesSpinner));
        ingredient.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ingredienteSeleccionado = parent.getItemAtPosition(position).toString();
                if (!ingredienteSeleccionado.equals("Ingredientes")) {
                    if(!ingredienteSeleccionado.equals("Otro")){
                        if(listaCantidadesReceta.size() == listaIngredientesReceta.size() || listaCantidadesReceta.size() > listaIngredientesReceta.size() ) {
                            listaIngredientesReceta.add(ingredienteSeleccionado);
                            listView.setAdapter(adaptador);
                            adaptador.notifyDataSetChanged();
                        }
                    }else {
                        nuevoIngrediente.setVisibility(View.VISIBLE);
                        guardar1.setVisibility(View.VISIBLE);

                    }
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        //Añadimos un escucha para cuando selecciones un ingrediente o una cantidad que borrar de la lista
        listCantidad.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){
                int item = position;

                if(listaCantidadesReceta.size() == listaIngredientesReceta.size()){
                    listaIngredientesReceta.remove(item);
                    listView.setAdapter(adaptador);
                    adaptador.notifyDataSetChanged();
                    listaCantidadesReceta.remove(item);
                    listCantidad.setAdapter(adaptadr);
                    adaptadr.notifyDataSetChanged();
                } else {
                    listaCantidadesReceta.remove(item);
                    listCantidad.setAdapter(adaptadr);
                    adaptadr.notifyDataSetChanged();
                }
            }
        });


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){
                int item = position;

                if(listaCantidadesReceta.size() == listaIngredientesReceta.size()){
                    listaIngredientesReceta.remove(item);
                    listView.setAdapter(adaptador);
                    adaptador.notifyDataSetChanged();
                    listaCantidadesReceta.remove(item);
                    listCantidad.setAdapter(adaptadr);
                    adaptadr.notifyDataSetChanged();
                } else {
                    listaIngredientesReceta.remove(item);
                    listView.setAdapter(adaptador);
                    adaptador.notifyDataSetChanged();
                }
            }
        });
        //botón que guarda el ingrediente en la base de datos, controla si se guarda o si existe, te indica que ya
        //esta en la base de datos
        guardar1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                esta = false;
                DatabaseReference ref = db.getReference("ingrediente");
                ref.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot dato : dataSnapshot.getChildren()) {
                            nuevo = dato.getValue(Ingrediente.class);
                            if(nuevo.getNombre().toUpperCase().equals(nuevoIngrediente.getText().toString().toUpperCase())){
                                esta = true;
                            }
                        }}
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) { }
                });
                if(esta){
                    if(!nuevoIngrediente.getText().toString().equals("")){
                        Ingrediente ingredienteNuevo = new Ingrediente(nuevoIngrediente.getText().toString());
                        key = ref.push().getKey();
                        ref.child(key).setValue(ingredienteNuevo);
                        nuevoIngrediente.setText("");
                        Toast.makeText(Ingredient.this, "Se guardó el ingrediente", Toast.LENGTH_LONG).show();
                    }
                }else {
                    nuevoIngrediente.setText("");
                    if (!nuevaCantidad.getText().toString().equals("")) {
                        Toast.makeText(Ingredient.this, "Ese ingrediente ya existe", Toast.LENGTH_LONG).show();
                    }
                }
                nuevoIngrediente.setVisibility(View.INVISIBLE);
                guardar1.setVisibility(View.INVISIBLE);
            }
        });

        //botón que guarda la cantidad en la base de datos, controla si se guarda o si existe, te indica que ya
        //esta en la base de datos
        guardar2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                estas = false;
                DatabaseReference refe = db.getReference("cantidad");
                refe.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot dato : dataSnapshot.getChildren()) {
                            nueva = dato.getValue(Cantidad.class);
                            if(nueva.getPeso().toUpperCase().equals(nuevaCantidad.getText().toString().toUpperCase())){
                                estas = true;
                            }
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) { }
                });
                if(estas){
                    if(!nuevaCantidad.getText().toString().equals("")){
                        Cantidad cantidadNueva = new Cantidad(nuevaCantidad.getText().toString());
                        key = refe.push().getKey();
                        refe.child(key).setValue(cantidadNueva);
                        nuevaCantidad.setText("");
                        Toast.makeText(Ingredient.this, "Se guardó la cantidad", Toast.LENGTH_LONG).show();
                    }
                }else{
                    nuevaCantidad.setText("");
                    if(!nuevaCantidad.getText().toString().equals("")) {
                        Toast.makeText(Ingredient.this, "Esa cantidad ya existe", Toast.LENGTH_LONG).show();
                    }
                }
                nuevaCantidad.setVisibility(View.INVISIBLE);
                guardar2.setVisibility(View.INVISIBLE);
            }
        });

        guardar = findViewById(R.id.guardar);

        //botón que guarda la lista de los ingredientes que hemos hecho y vuelve a nueva receta
        guardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editar.setListaIngredientes(listaIngredientesReceta);
                editar.setListaCantidades(listaCantidadesReceta);
                Intent intent = new Intent(Ingredient.this, NuevaReceta.class) ;
                Bundle bundle = new Bundle() ;
                bundle.putSerializable("receta", (Serializable) editar) ;
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
    }
}