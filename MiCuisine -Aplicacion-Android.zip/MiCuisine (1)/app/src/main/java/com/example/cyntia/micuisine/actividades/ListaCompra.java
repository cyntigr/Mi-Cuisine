package com.example.cyntia.micuisine.actividades;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import com.example.cyntia.micuisine.R;
import com.example.cyntia.micuisine.modelo.Usuario;
import com.google.firebase.database.FirebaseDatabase;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ListaCompra extends AppCompatActivity {
    private ListView listCompra;
    private ImageView atras;
    private EditText nuevo;
    private Button guardar;
    private Usuario usuario;
    private FirebaseDatabase db;
    ArrayList<String> listaComprar = new ArrayList<>();
    ArrayList<String> lista = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_compra);

        Bundle bundle = getIntent().getExtras() ;
        usuario =(Usuario) bundle.getSerializable("usuario");
        listCompra = findViewById(R.id.listaCompra);
        nuevo = findViewById(R.id.nuevaCompra);
        guardar = findViewById(R.id.guardarCompra);

        listaComprar = usuario.getListaCompras();
        lista = listaComprar;

        final ArrayAdapter adaptadorCompra = new ArrayAdapter(this, android.R.layout.simple_list_item_1, lista);
        listCompra.setAdapter(adaptadorCompra);

        listCompra.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){
                int item = position;

                lista.remove(item);
                usuario.setListaCompra(lista);
                adaptadorCompra.notifyDataSetChanged();
            }
        });

        guardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               usuario.setCompra(nuevo.getText().toString());
               nuevo.setText("");
               adaptadorCompra.notifyDataSetChanged();
            }
        });

        atras = findViewById(R.id.imagenAtras);
        atras.setClickable(true);
        atras.bringToFront();
        atras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentAtras = new Intent(ListaCompra.this, Inicio.class);
                startActivity(intentAtras) ;
            }
        });


    }

    // Para que no tenga funcionalidad el boton de volver atras.
    @Override
    public void onBackPressed(){
    }

}
