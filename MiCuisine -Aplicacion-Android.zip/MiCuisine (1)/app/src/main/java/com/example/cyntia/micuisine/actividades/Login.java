package com.example.cyntia.micuisine.actividades;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.example.cyntia.micuisine.R;
import com.example.cyntia.micuisine.modelo.Usuario;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.io.Serializable;


public class Login extends AppCompatActivity {


    private Button btnLogin, btnRegistro ;
    private EditText usuario, contrasena ;
    private TextView recordar;
    private RequestQueue queue ;
    private FirebaseAuth mAuth = FirebaseAuth.getInstance() ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //
        // Crea una cola de peticiones
        queue = Volley.newRequestQueue(this) ;

        usuario     = findViewById(R.id.Usuario) ;
        contrasena  = findViewById(R.id.Contrasena) ;
        btnLogin    = findViewById(R.id.Entrar) ;
        btnRegistro = findViewById(R.id.Registro) ;
        recordar    = findViewById(R.id.recuerda);
        //
        // Hacemos un listener para que este a la escucha de lo
        // que queremos hacer en registro.

        btnRegistro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View registro) {
                //
                // Con intent lo que hacemos es decirle que nuestra intención es irnos
                // al registro.

                Intent intent = new Intent(Login.this, Registro.class) ;

                intent.putExtra("mensaje","Registro de Mi Cuisine");
                startActivity(intent) ;
            }
        });

        // Con esta escucha estamos a la espera de los que han olvidado la contraseña
        // y quieren recuperar su contraseña.
        recordar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String user = usuario.getText().toString().trim();
                if(!user.isEmpty()){
                    mAuth.sendPasswordResetEmail(user);
                    Toast.makeText(Login.this, R.string.recuerda_bien, Toast.LENGTH_LONG).show();
                } else{
                    Toast.makeText(Login.this, R.string.error_recuerda, Toast.LENGTH_LONG).show();                }
            }
        });

        // Hacemos un listener para que este a la escucha de lo
        // que queremos hacer en login.
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View logearse) {

                // Cogemos información de los campos de texto
                final String user = usuario.getText().toString().trim();
                final String clave = contrasena.getText().toString().trim();

                // Comprobamos que han introducido el usuario y la contraseña
                if (user.isEmpty() || clave.isEmpty()) {
                    Snackbar.make(logearse, R.string.error_rellenar, Snackbar.LENGTH_LONG).show();
                } else {

                    // Realizamos el logueo con FireBase
                    loginWithFirebase(user, clave);
                }
            }
        });

    }

    private void loginWithFirebase(String user, String clave) {

        if (!user.isEmpty() && !clave.isEmpty()) {

            // Obtenemos instancia de Firebase (Authenticate)


            // Loguearnos con Firebase utilizando el correo y la contraseña
            mAuth.signInWithEmailAndPassword(user, clave).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {

                        // Recuperamos la información de la base de datos
                        // de Firebase
                        FirebaseDatabase db = FirebaseDatabase.getInstance() ;

                        // Creamos una referencia al documento USUARIOS
                        DatabaseReference ref = db.getReference("usuario") ;

                        // Obtenemos la información del usuario
                        ref.child(mAuth.getCurrentUser().getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                                if (dataSnapshot.exists()) {

                                    // Rescatamos la información devuelta por Firebase
                                    Usuario usuario = dataSnapshot.getValue(Usuario.class) ;

                                    // Creamos la intención
                                    Intent intent = new Intent(Login.this, Inicio.class) ;

                                    // Creamos un objeto de tipo Bundle
                                    Bundle bundle = new Bundle() ;
                                    bundle.putSerializable("usuario", (Serializable) usuario) ;

                                    // Asociamos el Bundle al Intent
                                    intent.putExtras(bundle);

                                    // Lanzar la actividad
                                    startActivity(intent) ;

                                }
                            }
                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    } else{

                        Toast.makeText(Login.this, "El usuario y/o la contraseña no coinciden", Toast.LENGTH_LONG).show();

                    }
                }
            });
        }

    }

    // Para que no tenga funcionalidad el boton de volver atras.
    @Override
    public void onBackPressed(){
    }

}
