package com.example.cyntia.micuisine.actividades;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Environment;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.example.cyntia.micuisine.R;
import com.example.cyntia.micuisine.modelo.Receta;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.HeaderFooter;
import com.lowagie.text.Image;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import harmony.java.awt.Color;

public class Mostrar extends AppCompatActivity {
    public Bundle bundle;
    private ImageView imagen;
    private TextView nombre,comensal,duracion,ingrediente,preparacion,consejo,categoria;
    private final static String NOMBRE_DIRECTORIO = "Recetas";
    private final String NOMBRE_DOCUMENTO = ".pdf";
    private final static String ETIQUETA_ERROR = "ERROR";
    Button btnGenerar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostrar);

        nombre = findViewById(R.id.nombreReceta);
        comensal = findViewById(R.id.comensalesReceta);
        duracion = findViewById(R.id.duracionReceta);
        ingrediente  = findViewById(R.id.ingredientesReceta);
        preparacion = findViewById(R.id.preparacionReceta);
        consejo = findViewById(R.id.consejosReceta);
        categoria = findViewById(R.id.categoriaReceta);
        final Button atras = findViewById(R.id.Cancelar);
        btnGenerar = findViewById(R.id.descargar);
        imagen = findViewById(R.id.camara);
        bundle = getIntent().getExtras();
        Receta receta = (Receta) bundle.getSerializable("receta");
        final Uri uri = Uri.parse(receta.getUri());
        String ingredientes = "";
        ArrayList<String> ingre = receta.getListaIngredientes();
        ArrayList<String> cant = receta.getListaCantidades();
        for(int i = 0; i < receta.getListaIngredientes().size();i++){
                ingredientes += ingre.get(i) + " " + cant.get(i) + "\n";
        }
        nombre.setText(receta.getNombre());
        comensal.setText(receta.getPersonas());
        duracion.setText(receta.getDuracion());
        ingrediente.setText(ingredientes);
        preparacion.setText(receta.getPreparacion());
        consejo.setText(receta.getConsejos());
        categoria.setText(receta.getCategoria());
        cargaImagen(uri);
        atras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View recetas) {
                //
                // Con intent lo que hacemos es decirle que nuestra intención es irnos
                // al layout de Recetas
                Intent intent = new Intent(Mostrar.this, Recetas.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });

        // Permisos.
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,}, 1000);
        } else {
        }
        // Generaremos el documento al hacer click sobre el boton.
        btnGenerar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                generarPdf();
                Toast.makeText(Mostrar.this, "Se guardo la receta en : ../Download/Recetas", Toast.LENGTH_LONG).show();

            }

        });

    }

    public void generarPdf() {

        // Creamos el documento.
        Document documento = new Document();

        try {

            File f = crearFichero(nombre.getText().toString() + NOMBRE_DOCUMENTO);

            // Creamos el flujo de datos de salida para el fichero donde
            // guardaremos el pdf.
            FileOutputStream ficheroPdf = new FileOutputStream(
                    f.getAbsolutePath());

            // Asociamos el flujo que acabamos de crear al documento.
            PdfWriter writer = PdfWriter.getInstance(documento, ficheroPdf);


            // Abrimos el documento.
            documento.open();

            //Creamos la tipografía que vayamos a utilizar dentro del PDF
            //
            Font fuenteTitulo = FontFactory.getFont(FontFactory.HELVETICA,30,Font.BOLD, harmony.java.awt.Color.BLACK);
            Font fuentes = FontFactory.getFont(FontFactory.HELVETICA,12,Font.NORMAL, Color.BLACK);

            //Creamos párrafo a párrafo la forma del PDF
            //
            documento.add(new Paragraph("" + nombre.getText().toString(), fuenteTitulo));
            documento.add(new Paragraph(" "));
            documento.add(new Paragraph("Categoría: " + categoria.getText().toString(),fuentes));
            documento.add(new Paragraph(" "));
            documento.add(new Paragraph("Comensales: " + comensal.getText().toString(),fuentes));
            documento.add(new Paragraph(" "));
            documento.add(new Paragraph("Duración: " + duracion.getText().toString(),fuentes));
            documento.add(new Paragraph(" "));
            documento.add(new Paragraph("Ingredientes: ",fuentes));
            documento.add(new Paragraph("" + ingrediente.getText().toString(),fuentes));
            documento.add(new Paragraph(" "));
            documento.add(new Paragraph("Preparación: ",fuentes));
            documento.add(new Paragraph(""+ preparacion.getText().toString(),fuentes));
            documento.add(new Paragraph(" "));
            documento.add(new Paragraph("Consejos: "+ consejo.getText().toString(),fuentes));
            documento.add(new Paragraph(" "));


        } catch (DocumentException e) {

            Log.e(ETIQUETA_ERROR, e.getMessage());

        } catch (IOException e) {

            Log.e(ETIQUETA_ERROR, e.getMessage());

        } finally {
            // Cerramos el documento.
            documento.close();
        }
    }


    public static File crearFichero(String nombreFichero) throws IOException {
        File ruta = getRuta();
        File fichero = null;
        if (ruta != null)
            fichero = new File(ruta, nombreFichero);
        return fichero;
    }

    /**
     * Obtenemos la ruta donde vamos a almacenar el fichero.
     *
     * @return
     */
    public static File getRuta() {

        // El fichero sera almacenado en un directorio dentro del directorio
        // Descargas
        File ruta = null;
        if (Environment.MEDIA_MOUNTED.equals(Environment
                .getExternalStorageState())) {
            ruta = new File(
                    Environment
                            .getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                    NOMBRE_DIRECTORIO);

            if (ruta != null) {
                if (!ruta.mkdirs()) {
                    if (!ruta.exists()) {
                        return null;
                    }
                }
            }
        } else {
        }

        return ruta;
    }


    private void cargaImagen(Uri uristr) {

        Glide.with(getApplicationContext())
                .load(uristr)
                .override(800,800)
                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        Log.i("RESULTADO", "Se ha producido un error");
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        return false;
                    }
                })
                .into(imagen);
    }
    // Para que no tenga funcionalidad el boton de volver atras.
    @Override
    public void onBackPressed(){
    }
}
