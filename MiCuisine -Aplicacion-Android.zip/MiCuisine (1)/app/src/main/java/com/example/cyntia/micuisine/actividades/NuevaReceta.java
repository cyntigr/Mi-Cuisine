package com.example.cyntia.micuisine.actividades;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.example.cyntia.micuisine.R;
import com.example.cyntia.micuisine.modelo.Receta;
import com.example.cyntia.micuisine.modelo.Usuario;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class NuevaReceta extends AppCompatActivity {
    private Usuario usuario ;
    private EditText nombre,personas,duracion;
    private EditText preparacion,consejos;
    private Button guardar, cancelar,ingredientes;
    private String catego;
    private String key;
    private FirebaseDatabase db ;
    private Receta editar;
    private ArrayAdapter<String> adaptadr;
    private String cate;
    private ImageView imagen;
    private Button hacerFoto, cargarFoto;
    private static final int RESULT_CARGAR_IMAGEN = 100 ;
    private static final int RESULT_TOMAR_FOTO    = 101 ;
    private static final int MIS_PERMISOS         =   1 ;
    private String rutaImagen ;
    FirebaseStorage storage = FirebaseStorage.getInstance();
    private StorageReference miStorage;
    private Uri uri = Uri.parse("https://firebasestorage.googleapis.com/v0/b/mi-cuisine.appspot.com/o/camara.png?alt=media&token=70756ee2-886b-451b-bb80-8bdc41fe6636");
    private StorageReference file = null;
    private ArrayList<String> listaIngrediente = new ArrayList<>();
    private ArrayList<String> listaCantidades = new ArrayList<>();
    private Integer visitas = 0;
    private Date fechaCreacion;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nueva_receta);
        final Bundle bundle = getIntent().getExtras();
        Date fecha = new Date();

        usuario = cogerUsuario();
        guardar = findViewById(R.id.Guardar) ;
        cancelar = findViewById(R.id.Cancelar);
        nombre = findViewById(R.id.nombre);
        personas = findViewById(R.id.personas);
        duracion = findViewById(R.id.duracion);
        preparacion = findViewById(R.id.preparacion);
        consejos = findViewById(R.id.consejo);
        imagen = findViewById(R.id.camara);
        hacerFoto = findViewById(R.id.btncamara);
        cargarFoto = findViewById(R.id.cargafoto);
        miStorage = FirebaseStorage.getInstance().getReference();
        ingredientes = findViewById(R.id.ingredientes);
        fechaCreacion = fecha;



        preparacion.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent event) {
                // TODO Auto-generated method stub
                if (view.getId() == R.id.preparacion) {
                    view.getParent().requestDisallowInterceptTouchEvent(true);
                    switch (event.getAction()&MotionEvent.ACTION_MASK){
                        case MotionEvent.ACTION_UP:
                            view.getParent().requestDisallowInterceptTouchEvent(false);
                            break;
                    }
                }
                return false;
            }
        });
        consejos.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent event) {
                // TODO Auto-generated method stub
                if (view.getId() == R.id.consejo) {
                    view.getParent().requestDisallowInterceptTouchEvent(true);
                    switch (event.getAction()&MotionEvent.ACTION_MASK){
                        case MotionEvent.ACTION_UP:
                            view.getParent().requestDisallowInterceptTouchEvent(false);
                            break;
                    }
                }
                return false;
            }
        });
        //
        //Spinner de las categorias
        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        String[] categoria = {"Entrante","Sopa","Verdura","Ensalada","Arroz","Pasta","Pescado","Marisco","Pollo","Cerdo","Ternera","Postre"};
        spinner.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categoria));
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                catego = parent.getItemAtPosition(position).toString() ; }
            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });

        // Obtenemos una instancia de la base de datos
        db = FirebaseDatabase.getInstance();

        if(bundle != null) {
            editar = (Receta) bundle.getSerializable("receta");
            nombre.setText(editar.getNombre());
            personas.setText(editar.getPersonas());
            duracion.setText(editar.getDuracion());
            preparacion.setText(editar.getPreparacion());
            consejos.setText(editar.getConsejos());
            listaIngrediente.addAll(editar.getListaIngredientes());
            listaCantidades = editar.getListaCantidades();
            key = editar.getIdReceta();
            cate = editar.getCategoria();
            adaptadr = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,categoria);
            spinner.setAdapter(adaptadr);
            int pos = adaptadr.getPosition(cate);
            spinner.setSelection(pos);
            uri = Uri.parse(editar.getUri());
            cargaImagen(uri);
            visitas = editar.getVisitas();
            fechaCreacion = editar.getFechaCreacion();
        }

        guardar.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {

            // Obtenemos una referencia al documento (tabla) que contendrá
            // la información. Si el documento no existe, Firebase lo crea.
            DatabaseReference referencia = db.getReference("receta");
            String uid = usuario.getIdUsuario();

            if(bundle == null) {
                key = referencia.push().getKey();
                // Preguntamos por el UID
                // Creamos nuestro objeto receta con los datos proporcionados
                // a través del formulario.

                Receta miReceta = new Receta(
                        key,
                        uid,
                        catego,
                        nombre.getText().toString(),
                        personas.getText().toString(),
                        duracion.getText().toString(),
                        preparacion.getText().toString(),
                        consejos.getText().toString(),
                        uri.toString(),
                        listaIngrediente,
                        listaCantidades,
                        visitas,fechaCreacion);
                // Guardamos la información en la base de datos de Firebase,
                // asociados al UID.


                referencia.child(key).setValue(miReceta);
                usuario.setReceta(key);
            } else {
                Boolean nuevo = true;
                ArrayList<String>recetasUsuario = usuario.getListaRecetas();
                for(String recetaUsu : recetasUsuario){
                    if(key.equals(recetaUsu)){
                        Receta mReceta = new Receta(
                                key, uid,
                                catego,
                                nombre.getText().toString(),
                                personas.getText().toString(),
                                duracion.getText().toString(),
                                preparacion.getText().toString(),
                                consejos.getText().toString(),
                                uri.toString(),
                                listaIngrediente,
                                listaCantidades,
                                visitas,fechaCreacion);
                        referencia.child(key).setValue(mReceta);
                        nuevo = false;
                    }
                }
                if(nuevo){
                    Receta miReceta = new Receta(
                            key,
                            uid,
                            catego,
                            nombre.getText().toString(),
                            personas.getText().toString(),
                            duracion.getText().toString(),
                            preparacion.getText().toString(),
                            consejos.getText().toString(),
                            uri.toString(),
                            listaIngrediente,
                            listaCantidades,
                            visitas,fechaCreacion);
                    referencia.child(key).setValue(miReceta);
                    usuario.setReceta(key);
                }
            }
            Intent intent = new Intent(NuevaReceta.this, Inicio.class);
            startActivity(intent);
            }
        });
        cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View atras) {
                //
                // Con intent lo que hacemos es decirle que nuestra intención es irnos
                // al layout de inicio
                Intent intent = new Intent(NuevaReceta.this, Inicio.class);
                startActivity(intent) ;
            }
        });
        //funciones a realizar para abrir la cámara
        //
        final String[] PERMISOS = { Manifest.permission.CAMERA,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_EXTERNAL_STORAGE } ;
        //solicitamos los permisos si no los tienen los pide
        if (!hayPermisos(PERMISOS)) {
            ActivityCompat.requestPermissions(this, PERMISOS, MIS_PERMISOS);
        }

        hacerFoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                File imagene = null ;
                // Abre la aplicación de la cámara
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE) ;
                if (intent.resolveActivity(getPackageManager()) != null) {
                    try
                    {
                        imagene = crearImagen() ;
                    }
                    catch (IOException except)
                    {
                        Log.e("PRUEBA_CAMARA::", "Se ha producido un error creando el archivo de imagen.") ;
                    }
                    // Aquí recogemos la dirección de la imagen que hemos capturado
                    if (imagene!=null) {
                        uri = FileProvider.getUriForFile(getApplicationContext(),
                                "com.example.cyntia.micuisine.provider",
                                imagene) ;
                        intent.putExtra(MediaStore.EXTRA_OUTPUT, uri) ;
                    }
                    startActivityForResult(intent, RESULT_TOMAR_FOTO) ;
                }
            }
        });

        ingredientes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String uid = usuario.getIdUsuario();
                if(bundle == null) {
                    DatabaseReference referencia = db.getReference("receta");
                    key = referencia.push().getKey();
                }

                Receta miReceta = new Receta(
                        key, uid, catego,
                        nombre.getText().toString(),
                        personas.getText().toString(),
                        duracion.getText().toString(),
                        preparacion.getText().toString(),
                        consejos.getText().toString(),
                        uri.toString(),
                        listaIngrediente, listaCantidades,
                        visitas,fechaCreacion);

                Bundle mediaReceta = new Bundle() ;
                mediaReceta.putSerializable("receta", (Serializable) miReceta) ;
                Intent intent = new Intent(NuevaReceta.this, Ingredient.class);
                intent.putExtras(mediaReceta);
                startActivity(intent);

            }
        });

        cargarFoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /* Creamos la intención, definimos el tipo de formato de imagen y la lanzamos
                   a la espera de una respuesta.*/
                Intent intent = new Intent(Intent.ACTION_PICK) ;
                intent.setType("image/*") ;
                startActivityForResult(intent, RESULT_CARGAR_IMAGEN);
            }
        });
    }




    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        //
        super.onActivityResult(requestCode, resultCode, data);
        switch(requestCode) {
            // Carga imagen de la galería del movil
            case RESULT_CARGAR_IMAGEN:
                if (resultCode==RESULT_OK){
                    cargaImagen(data.getData());
                }
                file = miStorage.child("fotos").child(uri.getLastPathSegment());
                file.putFile(uri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                        if (task.isSuccessful()) {
                            //getting storage string
                            String DownloadUrl = task.getResult().getStorage().getDownloadUrl().toString();

                            file.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri ur) {
                                    uri = ur;
                                }
                            });
                        }
                    }
                });

                break ;
            // La foto se ha hecho bien
            case RESULT_TOMAR_FOTO:
                if (resultCode==RESULT_OK) {
                    Glide.with(getApplicationContext())
                            .load(rutaImagen)
                            .override(800, 800)
                            .into(imagen) ;
                }
                file = miStorage.child("fotos").child(uri.getLastPathSegment());
                file.putFile(uri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                        if (task.isSuccessful()) {
                            //getting storage string
                            String DownloadUrl = task.getResult().getStorage().getDownloadUrl().toString();

                            file.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri ur) {
                                    uri = ur;
                                }
                            });
                        }
                    }
                });
                break;
            default:
                Log.i("RESULTADO", "No hace nada...") ;
        }
    }

    //Cargamos imagen con glide
    private void cargaImagen(Uri uristr) {
        Glide.with(getApplicationContext())
                .load(uristr)
                .override(800,800)
                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        Log.i("RESULTADO", "Se ha producido un error");
                        return false;
                    }
                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        return false;
                    }
                })
                .into(imagen);
        uri = uristr;
    }

    //Pedimos los permisos
    private Boolean hayPermisos(String ...permisos) {
        if (permisos!=null) {
            for (String permiso : permisos) {
                if (ActivityCompat.checkSelfPermission(NuevaReceta.this, permiso)!= PackageManager.PERMISSION_GRANTED) {
                    return false ;
                }
            }
        }
        return true ;
    }

    // Creamos el archivo en la tarjeta sd
    private File crearImagen() throws IOException {
        // Un texto con la fecha y la hora
        String marcaTiempo = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
                .format(new Date()) ;
        // Ahora creamos el nombre con la fecha
        String nombreImagen = "IMG_" + marcaTiempo + "_" ;
        //Obtenemos directorio externo donde almacenar
        File directorio = getExternalFilesDir(Environment.DIRECTORY_PICTURES) ;
        // Creamos el archivo temporal con el nombre y la extensión
        File imagen = File.createTempFile(nombreImagen, ".jpg", directorio) ;
        // Guardamos la ruta
        rutaImagen = imagen.getAbsolutePath() ;
        return imagen ;
    }

    private Usuario cogerUsuario(){
        final FirebaseAuth mAuth = FirebaseAuth.getInstance() ;
        db = FirebaseDatabase.getInstance();
        // Creamos una referencia al documento USUARIOS
        DatabaseReference ref = db.getReference("usuario") ;
        // Obtenemos la información del usuario
        ref.child(mAuth.getCurrentUser().getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Rescatamos la información devuelta por Firebase
                    usuario = dataSnapshot.getValue(Usuario.class);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
        return usuario;
    }

    // Para que no tenga funcionalidad el boton de volver atras.
    @Override
    public void onBackPressed(){
    }
}
