package com.example.cyntia.micuisine.actividades;

import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import com.example.cyntia.micuisine.R;
import com.example.cyntia.micuisine.fragmentos.masVistas;
import com.example.cyntia.micuisine.fragmentos.misRecetas;
import com.example.cyntia.micuisine.fragmentos.novedades;
import com.example.cyntia.micuisine.fragmentos.todasLasRecetas;
import com.example.cyntia.micuisine.modelo.Receta;
import com.example.cyntia.micuisine.modelo.Usuario;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

public class Recetas extends AppCompatActivity implements View.OnClickListener, masVistas.OnFragmentInteractionListener,
        misRecetas.OnFragmentInteractionListener,novedades.OnFragmentInteractionListener,todasLasRecetas.OnFragmentInteractionListener {

    private FirebaseDatabase db;
    public Receta recet;
    public ArrayList<Receta> listaRecetas = new ArrayList<>();
    public ArrayList<Receta> recetasUsuario = new ArrayList<>();
    public ArrayList<Receta> recetasMasRecientes = new ArrayList<>();
    public ArrayList<Receta> listaRecetasMasVistas = new ArrayList<>();

    public ArrayList<String> idRecetas = new ArrayList<>();
    private Usuario usuario;
    private  Bundle bundle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recetas);
         bundle = getIntent().getExtras() ;
         usuario =(Usuario) bundle.getSerializable("usuario");
        BottomNavigationView navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        idRecetas = usuario.getListaRecetas();
        db = FirebaseDatabase.getInstance();
        DatabaseReference ref = db.getReference("receta");

        //Aqui nos traemos la lista de recetas del usuario
        for(String r : idRecetas){
            if (r != null) {
                // Buscamos la información sobre las recetas
                ref.child(r).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        // Creamos la receta
                        recet = dataSnapshot.getValue(Receta.class);
                        recetasUsuario.add(recet);
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) { }
                });
            }
        }

        //Aquí nos traemos toda la lista de recetas de la base de datos metemos en las respectivas listas
        //que pasaremos a los fragmentos, en mi caso aquí dentro ordeno con la función sort de Collection
        //según los atributos que quiero
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot dato : dataSnapshot.getChildren()){
                    recet = dato.getValue(Receta.class);
                    listaRecetas.add(recet);
                    listaRecetasMasVistas.add(recet);
                    recetasMasRecientes.add(recet);
                }
                Collections.sort(listaRecetasMasVistas, new Comparator<Receta>() {
                    @Override
                    public int compare(Receta o1, Receta o2) {
                        return new Integer(o2.getVisitas()).compareTo(new Integer(o1.getVisitas()));
                    }
                });
                Collections.sort(recetasMasRecientes, new Comparator<Receta>() {
                    @Override
                    public int compare(Receta o1, Receta o2) {
                        return new Long(o2.getFechaCreacion().getTime()).compareTo(new Long(o1.getFechaCreacion().getTime()));
                    }
                });

            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
        //Aquí añadimos un fragmento predeterminado para cuando entramos por primera vez dentro de
        //la Activity Recetas nos aparezcan mis Recetas
        Fragment mas = new masVistas();
        bundle.putSerializable("listaRecet",listaRecetasMasVistas);
        mas.setArguments(bundle);
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.contenedor, mas)
                .commit() ;
    }

    //Botones de navegación, dependiendo que opción pulses en el menú te muestra un fragamento u otro
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {

            Fragment fragment = null ;
            switch (item.getItemId()) {

                case R.id.masVistas:
                    //Creamos un nuevo bundle para mandar el usuario y la lista de recetas
                    Bundle bundle2 = new Bundle();
                    bundle2.putSerializable("usuario",usuario);
                    bundle2.putSerializable("listaRecet",listaRecetasMasVistas);
                    //Aquí asignamos el fragmento que nos aparecera en pantalla según nos movamos
                    //por el menú
                    fragment = new masVistas();
                    //Con setArguments mandamos los datos a los fragmentos
                    fragment.setArguments(bundle2);
                    break ;
                case R.id.misRecetas:
                    Bundle bundle3 = new Bundle();
                    bundle3.putSerializable("usuario",usuario);
                    bundle3.putSerializable("listaRecetUsuario",recetasUsuario);
                    bundle3.putSerializable("idRecetas",idRecetas);

                    fragment = new misRecetas();
                    fragment.setArguments(bundle3);
                    break ;
                case R.id.novedades:
                    Bundle bundle1 = new Bundle();
                    bundle1.putSerializable("usuario",usuario);
                    bundle1.putSerializable("listaRecet",recetasMasRecientes);

                    fragment = new novedades();
                    fragment.setArguments(bundle1);
                    break ;

                case R.id.todasLasRecetas:
                    Bundle bundle4 = new Bundle();
                    bundle4.putSerializable("usuario",usuario);
                    bundle4.putSerializable("listaRecet",listaRecetas);

                    fragment = new todasLasRecetas();
                    fragment.setArguments(bundle4);

            }

            //Aquí preguntamos si es nulo el fragmento para asignarle el fragmento a la activity o no
            if (fragment != null) {
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.contenedor,fragment)
                        .commit() ;

                return true ;
            }

            return false;
        }
    };


    @Override
    public void onClick(View v) { }

    //Métodos que se pueden utilizar en los fragmentos, sumarReceta aumenta el contador de visitas
    //borrarReceta borra la receta de la base de datos. Puesto que en los fragmentos no se puede
    //utilizar la referencia a la base de datos
    @Override
    public void sumarReceta(Receta receta) {
        DatabaseReference referencia = db.getReference("receta");
        referencia.child(receta.getIdReceta()).setValue(receta);
    }

    @Override
    public void borrarReceta(Receta borra,ArrayList<String> idRecetasUsuario) {

        db.getReference("receta/" + borra.getIdReceta()).removeValue();
        idRecetas = idRecetasUsuario;
        Map<String, Object> childUpdates = new HashMap<>();
        childUpdates.put("/usuario/" + usuario.getIdUsuario()  +"/listaRecetas/", idRecetas);
        db.getReference().updateChildren(childUpdates);
    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }
    // Para que no tenga funcionalidad el boton de volver atras.
    @Override
    public void onBackPressed(){
    }
}
