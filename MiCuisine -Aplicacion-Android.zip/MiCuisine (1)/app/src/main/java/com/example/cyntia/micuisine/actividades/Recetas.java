package com.example.cyntia.micuisine.actividades;

import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import com.example.cyntia.micuisine.R;
import com.example.cyntia.micuisine.fragmentos.masVistas;
import com.example.cyntia.micuisine.fragmentos.misRecetas;
import com.example.cyntia.micuisine.fragmentos.novedades;
import com.example.cyntia.micuisine.fragmentos.todasLasRecetas;
import android.support.v4.app.FragmentTransaction;
import android.support.annotation.FloatRange;
import android.content.Intent;
import com.example.cyntia.micuisine.adaptador.adaptadorRecetas;
import android.widget.Toast;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.ContextMenu;
import com.example.cyntia.micuisine.modelo.Ingrediente;
import com.example.cyntia.micuisine.modelo.Receta;
import com.example.cyntia.micuisine.modelo.Usuario;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Recetas extends AppCompatActivity implements View.OnClickListener, masVistas.OnFragmentInteractionListener,
        misRecetas.OnFragmentInteractionListener,novedades.OnFragmentInteractionListener,todasLasRecetas.OnFragmentInteractionListener {

    /*private FirebaseDatabase db;
    private RecyclerView recycler;
    private adaptadorRecetas adapter ;

    public Receta recet;
    public ArrayList<Receta> listaRecetas = new ArrayList<>();
    public ArrayList<Receta> recetasUsuario = new ArrayList<>();
    public ArrayList<String> idRecetas = new ArrayList<>();*/
    private Usuario usuario;
    private  Bundle bundle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recetas);
         bundle = getIntent().getExtras() ;


        BottomNavigationView navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        Fragment mas = new masVistas() ;
        mas.setArguments(bundle);
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.contenedor, mas)
                .commit() ;


        /*



        // Instanciamos nuestro recyclerView
        recycler = findViewById(R.id.recyclerview) ;

        idRecetas = usuario.getListaRecetas();

        db = FirebaseDatabase.getInstance();
        DatabaseReference ref = db.getReference("receta");

        //Aqui nos traemos la lista de recetas del usuario
        for(String r : idRecetas){
            if (r != null) {
                // Buscamos la información sobre las recetas
                ref.child(r).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        // Creamos la receta
                        recet = dataSnapshot.getValue(Receta.class);
                        recetasUsuario.add(recet);
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) { }
                });
            }
        }
        //Aquí nos traemos toda la lista de recetas de la base de datos
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot dato : dataSnapshot.getChildren()){
                    recet = dato.getValue(Receta.class);
                    listaRecetas.add(recet);
                }

            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });


        // Creamos el adaptador
        adapter = new adaptadorRecetas(this, R.layout.activity_lista_recetas, listaRecetas) ;

        // Creamos el gestor del layout para el recyclerView
        LinearLayoutManager manager = new LinearLayoutManager(this) ;

        recycler.setAdapter(adapter);
        recycler.setLayoutManager(manager);
        //
        // Registramos el menú contextual
        registerForContextMenu(recycler) ;
    }
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        //
        super.onCreateContextMenu(menu, v, menuInfo);

        //
        getMenuInflater().inflate(R.menu.context_menu, menu) ;
        menu.setHeaderTitle("Elige la opción") ;
    }



    @Override
    public boolean onContextItemSelected(MenuItem item) {

        switch(item.getItemId()) {
            case R.id.ver:
                //Vemos información en otro layout
                Receta mostrar = listaRecetas.get(adapter.getPosicion());
                mostrar.sumaVisita();
                DatabaseReference referencia = db.getReference("receta");
                referencia.child(mostrar.getIdReceta()).setValue(mostrar);
                Intent intent = new Intent(Recetas.this, Mostrar.class);
                intent.putExtra("receta",mostrar);
                intent.putExtra("usuario",usuario);
                startActivity(intent) ;

                break ;
            case R.id.edita:
                //Vemos información en otro layout, comprobamos si la receta que intentamos editar es del
                //usuario que quiere editar, si no es del usuario creador no podra modificarla
                Receta editar = listaRecetas.get(adapter.getPosicion());
                for(Receta receta : recetasUsuario){
                    if(receta.getIdReceta().equals(editar.getIdReceta())){
                        Intent inten = new Intent(Recetas.this, NuevaReceta.class) ;
                        inten.putExtra("receta",editar);
                        inten.putExtra("usuario",usuario);
                        startActivity(inten) ;
                    }
                }
                break ;

            case R.id.borrar:
                //Solo el usuario que crea la receta puede borrarla, así que si otro usuario lo intenta no se podrá borrar
                Receta borra = listaRecetas.get(adapter.getPosicion());
                for(Receta receta : recetasUsuario){
                    if(receta.getIdReceta().equals(borra.getIdReceta())){
                        db.getReference("receta/" + listaRecetas.get(adapter.getPosicion()).getIdReceta()).removeValue();
                        idRecetas.remove(listaRecetas.get(adapter.getPosicion()).getIdReceta());

                        listaRecetas.remove(adapter.getPosicion());
                        Map<String, Object> childUpdates = new HashMap<>();

                        childUpdates.put("/usuario/" + usuario.getIdUsuario()  +"/listaRecetas/", idRecetas);

                        db.getReference().updateChildren(childUpdates);

                        adapter.notifyItemRemoved(adapter.getPosicion());
                    }
                }
                break ;
        }
        return false;*/

    }


    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {

            Fragment fragment = null ;

            switch (item.getItemId()) {
                case R.id.masVistas:
                    fragment = new masVistas() ;
                    fragment.setArguments(bundle);
                    break ;
                case R.id.misRecetas:
                    fragment = new misRecetas() ;
                    fragment.setArguments(bundle);
                    break ;
                case R.id.novedades:
                    fragment = new novedades() ;
                    fragment.setArguments(bundle);
                    break ;

                case R.id.todasLasRecetas:
                    fragment = new todasLasRecetas();
                    fragment.setArguments(bundle);
            }

            //
            if (fragment != null) {
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.contenedor,fragment)
                        .commit() ;

                return true ;
            }

            return false;
        }
    };

    @Override
    public void onClick(View v) {
    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }
}
