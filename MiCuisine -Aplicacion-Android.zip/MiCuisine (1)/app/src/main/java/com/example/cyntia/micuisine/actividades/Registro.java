package com.example.cyntia.micuisine.actividades;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.InputFilter;
import android.text.Spanned;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.cyntia.micuisine.R;
import com.example.cyntia.micuisine.modelo.Usuario;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class Registro extends AppCompatActivity {

    private EditText nombre, apellidos, email ;
    private EditText telefono, contrasena, contrasenaDos ;
    private Button btnRegistro,btnAtras ;

    private FirebaseAuth mAuth ;
    private FirebaseDatabase db ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        // Instanciamos y referenciamos los elementos de la UI

        nombre  = findViewById(R.id.Nombre) ;
        apellidos  = findViewById(R.id.Apellidos) ;
        email  = findViewById(R.id.Email) ;
        telefono  = findViewById(R.id.Telefono) ;
        contrasena = findViewById(R.id.Contrasen) ;
        contrasenaDos = findViewById(R.id.ConfirmarContrasena) ;
        btnRegistro = findViewById(R.id.Confirmar);
        btnAtras  = findViewById(R.id.Atras);

        //
        // Defino los filtros para cada uno de los campos del registro

        InputFilter alfaFilter = new InputFilter() {
            @Override
            public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {

                //
                // Filtro que controla si son letras
                for(int i=start; i<end; i++) {
                    if (Character.isDigit(source.charAt(i))) {
                        Toast.makeText(Registro.this,
                                R.string.error_alfabetico,
                                Toast.LENGTH_SHORT).show();
                        return "" ;
                    }
                }

                return null;
            }
        } ;

        InputFilter numFilter = new InputFilter() {
            @Override
            public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {

                //
                // Filtro que controla si son numeros
                for(int i=start; i<end; i++) {
                    if (!Character.isDigit(source.charAt(i))) {
                        Toast.makeText(Registro.this,
                                R.string.error_digitos,
                                Toast.LENGTH_SHORT).show();
                        return "" ;
                    }
                }

                return null;
            }
        } ;

        // Filtro que controla si son letras y números
        InputFilter alfanumFilter = new InputFilter() {
            @Override
            public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {

                for(int i=start; i<end; i++) {
                    if (!Character.isLetterOrDigit(source.charAt(i))) {
                        Toast.makeText(Registro.this,
                                R.string.error_alfanumerico,
                                Toast.LENGTH_SHORT).show();
                        return "" ;
                    }
                }

                return null;
            }
        } ;

        //
        // Asociamos los filtros a los campos
        nombre.setFilters(new InputFilter[] { alfaFilter } );
        apellidos.setFilters(new InputFilter[] { alfaFilter } );
        contrasena.setFilters(new InputFilter[] {  alfanumFilter, new InputFilter.LengthFilter(15) } );
        contrasenaDos.setFilters(new InputFilter[] { alfanumFilter, new InputFilter.LengthFilter(15) } );
        telefono.setFilters (new InputFilter[] { numFilter, new InputFilter.LengthFilter(9) } );

        //
        // Damos funcionalidad al botón de volver atras
        btnAtras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View login) {
                Intent intent = new Intent(Registro.this, Login.class);
                startActivity(intent);
            }
        });

        // Damos funcionalidad al botón de registro
        btnRegistro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View registro) {

                //
                // Obtenemos los valores introducidos por el usuario
                String usuario = email.getText().toString().trim() ;
                String clave   = contrasena.getText().toString().trim() ;
                String claveDos   = contrasenaDos.getText().toString().trim() ;
                if(clave.equals(claveDos)) {
                    // Obtenemos una instancia del objeto FirebaseAuth
                    mAuth = FirebaseAuth.getInstance();
                    mAuth.createUserWithEmailAndPassword(usuario, clave).addOnCompleteListener(
                            new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {

                                    if (task.isSuccessful()) {

                                        // Obtenemos una instancia de la base de datos
                                        db = FirebaseDatabase.getInstance();

                                        // Obtenemos una referencia al documento (tabla) que contendrá
                                        // la información. Si el documento no existe, Firebase lo crea.
                                        DatabaseReference ref = db.getReference("usuario");

                                        // Obtener los datos proporcionados por Firebase sobre el usuario
                                        // registrado.
                                        FirebaseUser fbUser = mAuth.getCurrentUser();

                                        // Preguntamos por el UID
                                        String uid = fbUser.getUid();

                                        // Creamos nuestro objeto usuario con los datos proporcionados
                                        // a través del formulario.
                                        Usuario miUsuario = new Usuario(uid,
                                                nombre.getText().toString(),
                                                apellidos.getText().toString(),
                                                email.getText().toString(),
                                                telefono.getText().toString());

                                        // Guardamos la información en la base de datos de Firebase,
                                        // asociados al UID.
                                        ref.child(uid).setValue(miUsuario);

                                        //
                                        // Volvemos a la pagina de inicio para que pueda logearse
                                        Intent intent = new Intent(Registro.this, Login.class);

                                        intent.putExtra("mensaje", "Registro creado satisfactoriamente");
                                        startActivity(intent);
                                    } else {

                                        Toast.makeText(Registro.this, "Se ha producido un error en el registro, vuelva a intentarlo.", Toast.LENGTH_LONG).show();
                                    }

                                }
                            });
                } else {
                    Toast.makeText(Registro.this, "Las contraseñas no coinciden.", Toast.LENGTH_LONG).show();

                }
            }
        });
    }
}
