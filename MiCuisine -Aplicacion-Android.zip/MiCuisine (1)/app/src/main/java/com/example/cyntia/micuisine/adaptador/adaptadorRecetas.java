package com.example.cyntia.micuisine.adaptador;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.example.cyntia.micuisine.R;
import com.example.cyntia.micuisine.modelo.Receta;
import java.util.ArrayList;


public class adaptadorRecetas extends
        RecyclerView.Adapter<adaptadorRecetas.RecetasHolder> {

    private ArrayList<Receta> recetas = new ArrayList<Receta>();
    private int layout ;
    private Context contexto ;
    private int posicion ;

    public adaptadorRecetas(Context contexto, int layout,ArrayList<Receta> recetas ) {
        this.recetas = recetas;
        this.layout = layout;
        this.contexto = contexto;
    }

    @NonNull
    @Override
    public RecetasHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        // Inflamos el layout y obtenemos la vista
        View vista = LayoutInflater.from(viewGroup.getContext()).inflate(this.layout, null) ;

        // Devuelve una nueva instancia de viewholder, aquí enganchamos la vista al viewHolder
        RecetasHolder holder = new RecetasHolder(vista);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecetasHolder recetasHolder, int position) {
        recetasHolder.bindItem(this.recetas.get(position), position);
    }

    // Devuelve la cuenta total de los item de la lista
    @Override
    public int getItemCount() {
        return this.recetas.size();
    }

    public int getPosicion() {
        return posicion;
    }

    public class RecetasHolder extends RecyclerView.ViewHolder {

        private TextView nombre;

        public RecetasHolder(@NonNull View itemView) {

            super(itemView);

            nombre = itemView.findViewById(R.id.nombreRecetas);

            //
            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    posicion = getAdapterPosition() ;
                    return false;
                }
            });
        }

        public void bindItem(Receta item, int position) {
            //
            nombre.setText(item.getNombre()) ;
        }
    }
}