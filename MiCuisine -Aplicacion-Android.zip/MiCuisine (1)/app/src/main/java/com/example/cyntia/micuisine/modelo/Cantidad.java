package com.example.cyntia.micuisine.modelo;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Cantidad {
    @Expose
    @SerializedName("peso")
    private String peso;

    public Cantidad() { }

    public Cantidad(String peso) {
        this.peso = peso;
    }

    public String getPeso() {
        return peso;
    }

    public void setPeso(String peso) {
        this.peso = peso;
    }

    @Override
    public String toString() {
        return "Cantidad{" +
                "peso='" + peso + '\'' +
                '}';
    }
}
