package com.example.cyntia.micuisine.modelo;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class Receta implements Serializable {

    private FirebaseDatabase db;

    @Expose
    @SerializedName("idReceta")
    private String  idReceta;
    @Expose
    @SerializedName("idUsuario")
    private String  idUsuario;
    @Expose
    @SerializedName("categoria")
    private String categoria ;
    @Expose
    @SerializedName("nombre")
    private String nombre ;
    @Expose
    @SerializedName("personas")
    private String personas ;
    @Expose
    @SerializedName("duracion")
    private String duracion ;
    @Expose
    @SerializedName("preparacion")
    private String preparacion ;
    @Expose
    @SerializedName("visitas")
    private Integer visitas ;
    @Expose
    @SerializedName("consejos")
    private String consejos;
    @Expose
    @SerializedName("uri")
    private String uri;
    @Expose
    @SerializedName("fechaCreacion")
    private Date fechaCreacion;
    @Expose
    @SerializedName("listaIngredientes")
    private ArrayList<String> listaIngredientes = new ArrayList<String>();
    @Expose
    @SerializedName("listaCantidades")
    private ArrayList<String> listaCantidades = new ArrayList<String>();

    public Receta() {
    }

    public Receta(String idReceta, String idUsuario, String categoria, String nombre,
                  String personas, String duracion, String preparacion,
                  String consejos, String uri, ArrayList<String> listaIngredientes,
                  ArrayList<String> listaCantidades,Integer visitas, Date fechaCreacion) {
        this.idReceta = idReceta;
        this.idUsuario = idUsuario;
        this.categoria = categoria;
        this.nombre = nombre;
        this.personas = personas;
        this.duracion = duracion;
        this.preparacion = preparacion;
        this.consejos = consejos;
        this.uri = uri;
        this.listaIngredientes = listaIngredientes;
        this.listaCantidades = listaCantidades;
        this.visitas = visitas;
        this.fechaCreacion = fechaCreacion;
    }

    public Date getFechaCreacion() { return fechaCreacion; }

    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public Integer getVisitas() { return visitas; }

    public void setVisitas(Integer visitas) { this.visitas = visitas; }

    public ArrayList<String> getListaCantidades() {
        return listaCantidades;
    }

    public void setListaCantidades(ArrayList<String> listaCantidad) { this.listaCantidades = listaCantidad; }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public String getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(String idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getIdReceta() {
        return idReceta;
    }

    public void setIdReceta(String idReceta) {
        this.idReceta = idReceta;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPersonas() {
        return personas;
    }

    public void setPersonas(String personas) {
        this.personas = personas;
    }

    public String getDuracion() {
        return duracion;
    }

    public void setDuracion(String duracion) {
        this.duracion = duracion;
    }

    public String getPreparacion() {
        return preparacion;
    }

    public void setPreparacion(String preparacion) {
        this.preparacion = preparacion;
    }

    public String getConsejos() {
        return consejos;
    }

    public void sumaVisita() { this.visitas += 1; }

    public void setConsejos(String consejos) {
        this.consejos = consejos;
    }

    public ArrayList<String> getListaIngredientes() {
        return listaIngredientes;
    }

    public void setListaIngredientes(ArrayList<String> listaIngredientes) {
        this.listaIngredientes = listaIngredientes;
    }

    public void setCantidad(String idCantidad) {
        this.listaIngredientes.add(idCantidad);

        db = FirebaseDatabase.getInstance();
        DatabaseReference ref = db.getReference("receta");
        ref.child(this.idReceta).setValue(this);
    }

    public void setIngrediente(String idIngrediente) {
        this.listaIngredientes.add(idIngrediente);

        db = FirebaseDatabase.getInstance();
        DatabaseReference ref = db.getReference("receta");
        ref.child(this.idReceta).setValue(this);
    }

    @Override
    public String toString() {
        return "Receta{" +
                "idReceta='" + idReceta + '\'' +
                ", idUsuario='" + idUsuario + '\'' +
                ", categoria='" + categoria + '\'' +
                ", nombre='" + nombre + '\'' +
                ", personas='" + personas + '\'' +
                ", duracion='" + duracion + '\'' +
                ", preparacion='" + preparacion + '\'' +
                ", visitas=" + visitas +
                ", consejos='" + consejos + '\'' +
                ", uri='" + uri + '\'' +
                ", fechaCreacion=" + fechaCreacion +
                ", listaIngredientes=" + listaIngredientes +
                ", listaCantidades=" + listaCantidades +
                '}';
    }
}