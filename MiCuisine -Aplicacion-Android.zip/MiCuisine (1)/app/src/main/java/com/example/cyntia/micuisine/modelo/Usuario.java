package com.example.cyntia.micuisine.modelo;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Usuario implements Serializable {

    @Expose
    @SerializedName("idUsuario")
    private String idUsuario;
    @Expose
    @SerializedName("nombre")
    private String nombre;
    @Expose
    @SerializedName("apellidos")
    private String apellidos;
    @Expose
    @SerializedName("email")
    private String email;
    @Expose
    @SerializedName("telefono")
    private String telefono;
    @Expose
    @SerializedName("listaRecetas")
    private ArrayList<String> listaRecetas = new ArrayList<String>();
    @Expose
    @SerializedName("listaCompra")
    private ArrayList<String> listaCompras = new ArrayList<String>();

    public ArrayList<String> getListaCompras() {
        return listaCompras;
    }

    public void setListaCompras(ArrayList<String> listaCompras) {
        this.listaCompras = listaCompras;
    }

    public Usuario() {
    }

    public Usuario(String idUsuario, String nombre, String apellidos,
                   String email, String telefono) {
        this.idUsuario = idUsuario;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.email = email;
        this.telefono = telefono;
    }

    public String getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(String idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public ArrayList<String> getListaRecetas() {
        return listaRecetas;
    }

    public void setListaRecetas(ArrayList<String> listaRecetas) {
        this.listaRecetas = listaRecetas;
    }

    private FirebaseDatabase db;

    public void setReceta(String idReceta) {
        this.listaRecetas.add(idReceta);

        db = FirebaseDatabase.getInstance();
        DatabaseReference ref = db.getReference("usuario");

        ref.child(this.idUsuario).setValue(this);
    }

    public void setCompra(String compra){
        this.listaCompras.add(compra);
        db = FirebaseDatabase.getInstance();
        DatabaseReference ref = db.getReference("usuario");
        ref.child(this.idUsuario).setValue(this);
    }

    public void setListaCompra(ArrayList<String> listaCompras) {
        this.listaCompras = listaCompras;
        db = FirebaseDatabase.getInstance();
        DatabaseReference ref = db.getReference("usuario");
        ref.child(this.idUsuario).setValue(this);
    }

    @Override
    public String toString() {
        return "Usuario{" +
                "idUsuario='" + idUsuario + '\'' +
                ", nombre='" + nombre + '\'' +
                ", apellidos='" + apellidos + '\'' +
                ", email='" + email + '\'' +
                ", telefono='" + telefono + '\'' +
                ", listaRecetas=" + listaRecetas +
                ", listaCompras=" + listaCompras +
                ", db=" + db +
                '}';
    }
}