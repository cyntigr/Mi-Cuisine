alter table SYS_CATEGORY_ATTR add DEFAULT_STR_ENTITY_VALUE varchar(255)^
alter table SYS_CATEGORY_ATTR add DEFAULT_INT_ENTITY_VALUE integer^
alter table SYS_CATEGORY_ATTR add DEFAULT_LONG_ENTITY_VALUE bigint^

alter table SYS_ATTR_VALUE add STRING_ENTITY_ID varchar(255)^
alter table SYS_ATTR_VALUE add INT_ENTITY_ID integer^
alter table SYS_ATTR_VALUE add LONG_ENTITY_ID bigint^

alter table SYS_ATTR_VALUE add STRING_ENTITY_VALUE varchar(255)^
alter table SYS_ATTR_VALUE add INT_ENTITY_VALUE integer^
alter table SYS_ATTR_VALUE add LONG_ENTITY_VALUE bigint^