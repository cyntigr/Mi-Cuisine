-- Increase length of SEC_CONSTRAINT columns

alter table SEC_CONSTRAINT alter column GROOVY_SCRIPT longvarchar^

alter table SEC_CONSTRAINT alter column FILTER_XML longvarchar^
