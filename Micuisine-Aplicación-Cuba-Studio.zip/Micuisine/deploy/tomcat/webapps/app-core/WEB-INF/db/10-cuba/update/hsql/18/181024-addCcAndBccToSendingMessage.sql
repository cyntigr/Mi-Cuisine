alter table SYS_SENDING_MESSAGE add ADDRESS_CC longvarchar;
alter table SYS_SENDING_MESSAGE add ADDRESS_BCC longvarchar;