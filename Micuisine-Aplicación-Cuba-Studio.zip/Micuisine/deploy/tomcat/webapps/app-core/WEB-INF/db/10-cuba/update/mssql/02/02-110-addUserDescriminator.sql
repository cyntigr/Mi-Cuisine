
alter table SEC_USER add TYPE varchar(1)^

update SEC_USER set TYPE = 'C'^