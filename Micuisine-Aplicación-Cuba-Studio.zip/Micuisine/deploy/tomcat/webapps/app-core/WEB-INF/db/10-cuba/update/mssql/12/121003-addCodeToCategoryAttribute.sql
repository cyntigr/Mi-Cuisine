-- Description: add code field to CategoryAttribute

alter table SYS_CATEGORY_ATTR add CODE varchar(50);