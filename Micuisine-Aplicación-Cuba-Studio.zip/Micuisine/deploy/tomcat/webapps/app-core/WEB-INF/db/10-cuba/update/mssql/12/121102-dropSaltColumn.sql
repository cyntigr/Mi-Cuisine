-- Description: drop SALT column in SEC_USER

alter table SEC_USER drop column SALT^