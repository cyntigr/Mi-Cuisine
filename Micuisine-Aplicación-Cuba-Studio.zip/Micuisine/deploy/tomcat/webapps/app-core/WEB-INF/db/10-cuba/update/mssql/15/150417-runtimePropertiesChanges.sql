alter table SYS_ATTR_VALUE add CODE varchar(100)^
alter table SYS_CATEGORY_ATTR add TARGET_SCREENS varchar(4000)^

