alter table SYS_FTS_QUEUE add FAKE tinyint^
