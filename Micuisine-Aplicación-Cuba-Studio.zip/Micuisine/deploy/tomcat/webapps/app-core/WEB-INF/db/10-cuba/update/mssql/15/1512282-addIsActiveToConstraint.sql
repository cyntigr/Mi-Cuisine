alter table SEC_CONSTRAINT add IS_ACTIVE tinyint default 1^

