alter table SYS_SENDING_MESSAGE add ADDRESS_CC varchar(max);
alter table SYS_SENDING_MESSAGE add ADDRESS_BCC varchar(max);