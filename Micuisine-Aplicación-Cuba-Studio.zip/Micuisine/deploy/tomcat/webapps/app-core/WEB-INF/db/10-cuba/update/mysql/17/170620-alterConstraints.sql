-- Increase length of SEC_CONSTRAINT columns

alter table SEC_CONSTRAINT modify GROOVY_SCRIPT text^

alter table SEC_CONSTRAINT modify FILTER_XML text^
