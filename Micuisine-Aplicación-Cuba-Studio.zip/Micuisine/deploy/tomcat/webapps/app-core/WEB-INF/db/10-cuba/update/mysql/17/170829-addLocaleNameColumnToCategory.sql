alter table SYS_CATEGORY_ATTR add LOCALE_NAMES varchar(1000)^
alter table SYS_CATEGORY_ATTR add ENUMERATION_LOCALES text^
alter table SYS_CATEGORY add LOCALE_NAMES varchar(1000)^