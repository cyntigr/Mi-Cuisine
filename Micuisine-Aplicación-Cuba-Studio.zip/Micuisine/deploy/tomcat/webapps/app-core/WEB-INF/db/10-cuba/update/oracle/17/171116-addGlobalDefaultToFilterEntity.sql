alter table SEC_FILTER add GLOBAL_DEFAULT char(1)^
update SEC_FILTER set GLOBAL_DEFAULT = 0^
