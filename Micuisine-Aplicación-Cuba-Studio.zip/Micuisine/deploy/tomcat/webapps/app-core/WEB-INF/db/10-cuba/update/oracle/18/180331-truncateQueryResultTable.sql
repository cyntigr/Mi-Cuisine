-- Truncate SYS_QUERY_RESULT table

truncate table SYS_QUERY_RESULT^
