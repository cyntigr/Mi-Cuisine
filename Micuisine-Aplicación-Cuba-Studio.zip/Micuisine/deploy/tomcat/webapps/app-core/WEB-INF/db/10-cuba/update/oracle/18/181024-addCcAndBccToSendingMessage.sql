alter table SYS_SENDING_MESSAGE add ADDRESS_CC clob^
alter table SYS_SENDING_MESSAGE add ADDRESS_BCC clob^