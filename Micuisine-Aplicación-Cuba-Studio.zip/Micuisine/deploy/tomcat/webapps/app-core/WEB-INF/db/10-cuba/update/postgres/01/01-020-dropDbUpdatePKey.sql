-- Description: Moving to the new update database mechanism

alter table SYS_DB_UPDATE drop constraint SYS_DB_UPDATE_PKEY;

