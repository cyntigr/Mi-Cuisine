-- Description: sec_user.language_ field

alter table SEC_USER add LANGUAGE_ varchar(10)
^
