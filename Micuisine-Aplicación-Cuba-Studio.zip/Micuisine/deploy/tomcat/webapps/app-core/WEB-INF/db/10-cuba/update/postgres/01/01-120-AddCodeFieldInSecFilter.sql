-- Description: adding field in SEC_FILTER

alter table SEC_FILTER  add column CODE varchar(200);