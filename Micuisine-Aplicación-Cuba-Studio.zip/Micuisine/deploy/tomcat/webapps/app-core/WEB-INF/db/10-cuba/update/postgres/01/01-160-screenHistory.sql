-- Description:

alter table SEC_TAB_HISTORY rename to SEC_SCREEN_HISTORY^

alter table SEC_SCREEN_HISTORY rename column CREATOR_ID to USER_ID^