-- Description: add SYS_ENTITY_STATISTICS.FETCH_UI column

alter table SYS_ENTITY_STATISTICS add FETCH_UI integer^
