-- Description:
alter table SYS_CATEGORY_ATTR alter column DATA_TYPE type varchar(200);