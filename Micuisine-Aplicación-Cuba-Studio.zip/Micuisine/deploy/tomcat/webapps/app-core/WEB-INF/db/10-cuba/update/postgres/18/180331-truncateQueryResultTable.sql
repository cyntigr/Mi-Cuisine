-- Truncate SYS_QUERY_RESULT table

truncate SYS_QUERY_RESULT;
