alter table SYS_SENDING_MESSAGE add ADDRESS_CC text;
alter table SYS_SENDING_MESSAGE add ADDRESS_BCC text;