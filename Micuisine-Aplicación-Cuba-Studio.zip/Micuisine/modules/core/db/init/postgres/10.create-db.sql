-- begin MICUISINE_USUARIO
create table MICUISINE_USUARIO (
    ID varchar(36) not null,
    VERSION integer not null,
    CREATE_TS timestamp,
    CREATED_BY varchar(50),
    UPDATE_TS timestamp,
    UPDATED_BY varchar(50),
    DELETE_TS timestamp,
    DELETED_BY varchar(50),
    --
    NOMBRE varchar(255),
    APELLIDOS varchar(255),
    EMAIL varchar(255),
    TELEFONO varchar(255),
    --
    primary key (ID)
)^
-- end MICUISINE_USUARIO
-- begin MICUISINE_INGREDIENTE
create table MICUISINE_INGREDIENTE (
    ID varchar(36) not null,
    VERSION integer not null,
    CREATE_TS timestamp,
    CREATED_BY varchar(50),
    UPDATE_TS timestamp,
    UPDATED_BY varchar(50),
    DELETE_TS timestamp,
    DELETED_BY varchar(50),
    --
    NOMBRE varchar(255),
    --
    primary key (ID)
)^
-- end MICUISINE_INGREDIENTE
-- begin MICUISINE_CANTIDAD
create table MICUISINE_CANTIDAD (
    ID varchar(36) not null,
    VERSION integer not null,
    CREATE_TS timestamp,
    CREATED_BY varchar(50),
    UPDATE_TS timestamp,
    UPDATED_BY varchar(50),
    DELETE_TS timestamp,
    DELETED_BY varchar(50),
    --
    PESO varchar(255),
    --
    primary key (ID)
)^
-- end MICUISINE_CANTIDAD
-- begin MICUISINE_RECETA
create table MICUISINE_RECETA (
    ID uuid,
    VERSION integer not null,
    CREATE_TS timestamp,
    CREATED_BY varchar(50),
    UPDATE_TS timestamp,
    UPDATED_BY varchar(50),
    DELETE_TS timestamp,
    DELETED_BY varchar(50),
    --
    CATEGORIA integer,
    NOMBRE varchar(255),
    PERSONAS varchar(255),
    DURACION varchar(255),
    PREPARACION varchar(255),
    VISITAS integer,
    CONSEJOS varchar(255),
    URI varchar(255),
    FECHA_CREACION date,
    USUARIO_ID uuid,
    --
    primary key (ID)
)^
-- end MICUISINE_RECETA
-- begin MICUISINE_RECETA_INGREDIENTE_LINK
create table MICUISINE_RECETA_INGREDIENTE_LINK (
    RECETA_ID varchar(36) not null,
    INGREDIENTE_ID varchar(36) not null,
    primary key (RECETA_ID, INGREDIENTE_ID)
)^
-- end MICUISINE_RECETA_INGREDIENTE_LINK
-- begin MICUISINE_RECETA_CANTIDAD_LINK
create table MICUISINE_RECETA_CANTIDAD_LINK (
    RECETA_ID varchar(36) not null,
    CANTIDAD_ID varchar(36) not null,
    primary key (RECETA_ID, CANTIDAD_ID)
)^
-- end MICUISINE_RECETA_CANTIDAD_LINK

-- begin MICUISINE_RECETAS_POR_USUARIO
create table MICUISINE_RECETAS_POR_USUARIO (
    ID uuid,
    --
    USUARIO varchar(255),
    CANTIDAD_RECETAS integer,
    --
    primary key (ID)
)^
-- end MICUISINE_RECETAS_POR_USUARIO
-- begin MICUISINE_RECETAS_POR_DIA
create table MICUISINE_RECETAS_POR_DIA (
    ID uuid,
    --
    FECHA varchar(255),
    CANTIDAD_RECETAS integer,
    --
    primary key (ID)
)^
-- end MICUISINE_RECETAS_POR_DIA
-- begin MICUISINE_INGREDIENTES_MAS_UTILIZADOS
create table MICUISINE_INGREDIENTES_MAS_UTILIZADOS (
    ID uuid,
    --
    INGREDIENTE varchar(255),
    CANTIDAD integer,
    --
    primary key (ID)
)^
-- end MICUISINE_INGREDIENTES_MAS_UTILIZADOS
