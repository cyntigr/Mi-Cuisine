alter table MICUISINE_RECETA rename column categoria to categoria__u32544 ;
alter table MICUISINE_RECETA add column CATEGORIA integer ;
