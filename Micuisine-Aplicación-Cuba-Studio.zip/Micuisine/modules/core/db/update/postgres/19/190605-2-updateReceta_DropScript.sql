alter table MICUISINE_RECETA drop column CATEGORIA__U32544 cascade ;
