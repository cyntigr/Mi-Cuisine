create table MICUISINE_RECETAS_POR_DIA (
    ID uuid,
    --
    FECHA date,
    CANTIDAD_RECETAS integer,
    --
    primary key (ID)
);