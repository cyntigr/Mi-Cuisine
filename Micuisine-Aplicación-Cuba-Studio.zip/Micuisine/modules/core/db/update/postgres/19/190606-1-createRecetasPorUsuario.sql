create table MICUISINE_RECETAS_POR_USUARIO (
    ID uuid,
    --
    USUARIO varchar(255),
    CANTIDAD_RECETAS varchar(255),
    --
    primary key (ID)
);