alter table MICUISINE_RECETAS_POR_DIA rename column fecha to fecha__u11028 ;
alter table MICUISINE_RECETAS_POR_DIA add column FECHA varchar(255) ;
