alter table MICUISINE_RECETAS_POR_DIA drop column FECHA__U11028 cascade ;
