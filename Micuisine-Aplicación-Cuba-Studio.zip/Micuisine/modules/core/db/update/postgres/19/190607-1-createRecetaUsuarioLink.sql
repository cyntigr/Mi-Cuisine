create table MICUISINE_RECETA_USUARIO_LINK (
    USUARIO_ID uuid,
    RECETA_ID uuid,
    primary key (USUARIO_ID, RECETA_ID)
);
