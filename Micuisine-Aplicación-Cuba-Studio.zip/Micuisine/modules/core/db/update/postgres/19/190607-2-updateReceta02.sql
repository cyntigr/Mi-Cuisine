alter table MICUISINE_RECETA rename column usuarios_id to usuarios_id__u69290 ;
drop index IDX_MICUISINE_RECETA_ON_USUARIOS ;
alter table MICUISINE_RECETA drop constraint FK_MICUISINE_RECETA_ON_USUARIOS ;
alter table MICUISINE_RECETA add column USUARIO_ID uuid ;
