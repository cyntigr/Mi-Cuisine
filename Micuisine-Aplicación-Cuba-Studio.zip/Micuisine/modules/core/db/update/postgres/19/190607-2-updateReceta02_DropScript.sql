alter table MICUISINE_RECETA drop column USUARIOS_ID__U69290 cascade ;
