create table MICUISINE_INGREDIENTES_MAS_UTILIZADOS (
    ID uuid,
    --
    INGREDIENTE varchar(255),
    CANTIDAD integer,
    --
    primary key (ID)
);