alter table MICUISINE_RECETAS_POR_USUARIO rename column cantidad_recetas to cantidad_recetas__u81473 ;
alter table MICUISINE_RECETAS_POR_USUARIO add column CANTIDAD_RECETAS integer ;
