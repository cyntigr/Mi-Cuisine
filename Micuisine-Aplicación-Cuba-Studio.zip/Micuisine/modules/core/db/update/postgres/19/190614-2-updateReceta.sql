alter table MICUISINE_RECETA rename column usuario_id to usuario_id__u95635 ;
