alter table MICUISINE_RECETA add column USUARIO_ID uuid ;
