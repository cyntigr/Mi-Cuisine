-- update MICUISINE_RECETA set USUARIO_ID = <default_value> where USUARIO_ID is null ;
alter table MICUISINE_RECETA alter column USUARIO_ID set not null ;
