alter table MICUISINE_RECETA alter column USUARIO_ID drop not null ;
