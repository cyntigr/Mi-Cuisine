alter table MICUISINE_RECETA drop column USUARIO_ID__U95635 cascade ;
