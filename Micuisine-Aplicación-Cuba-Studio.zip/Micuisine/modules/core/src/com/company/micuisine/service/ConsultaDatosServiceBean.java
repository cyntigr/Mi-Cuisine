package com.company.micuisine.service;

import com.company.micuisine.entity.RecetasPorDia;
import com.company.micuisine.entity.RecetasPorUsuario;
import com.company.micuisine.entity.Usuario;
import com.haulmont.cuba.core.EntityManager;
import com.haulmont.cuba.core.Persistence;
import com.haulmont.cuba.core.Query;
import com.haulmont.cuba.core.Transaction;
import com.haulmont.cuba.core.global.DataManager;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

@Service(ConsultaDatosService.NAME)
public class ConsultaDatosServiceBean implements ConsultaDatosService {

    @Inject
    private Persistence persistence;


    @Override
    public List<RecetasPorDia> traerRecetasPorDia(){

        List<Object[]> lista = new ArrayList<>();

        try (Transaction tx = persistence.createTransaction()) {

            EntityManager em = persistence.getEntityManager();
            Query query = em.createNativeQuery(
                    "select fecha_creacion,count(nombre) from micuisine_receta group by fecha_creacion");
            lista = query.getResultList();
            tx.commit();
        }
        List<RecetasPorDia> recetasDia = new ArrayList<>();
        for(Object[] dias : lista){
            RecetasPorDia dia = new RecetasPorDia();
            String fecha = "" + dias[0];
            if (!fecha.equals("null")){
                dia.setFecha(fecha);
                dia.setCantidadRecetas(Integer.parseInt("" + dias[1]));
                recetasDia.add(dia);
            }
        }
        return recetasDia;
    }

    @Override
    public List<RecetasPorUsuario> traerRecetasUsuario(){
        List<Object[]> lista = new ArrayList<>();
        try (Transaction tx = persistence.createTransaction()) {

            EntityManager em = persistence.getEntityManager();
            Query query = em.createNativeQuery(
                    "select usuario_id, count(usuario_id) from micuisine_receta group by usuario_id");
            lista = query.getResultList();
            tx.commit();
        }
        List<RecetasPorUsuario> listaRecetasPorUsuario = new ArrayList<>();
        for(Object[] obj : lista){
            RecetasPorUsuario recetasUsuario = new RecetasPorUsuario();
            recetasUsuario.setUsuario(""+obj[0]);
            recetasUsuario.setCantidadRecetas(Integer.parseInt(""+obj[1]));
            listaRecetasPorUsuario.add(recetasUsuario);
        }
        return listaRecetasPorUsuario ;
    }


    @Override
    public Usuario traerUsuario(String id){

        List<Object[]> lista = new ArrayList<>();
        // start transaction
        try (Transaction tx = persistence.createTransaction()) {
            // get EntityManager for the current transaction
            EntityManager em = persistence.getEntityManager();
            // create and execute Query
            Query query = em.createNativeQuery(
                    "select * from micuisine_usuario p where p.id = '" + id + "'");
            lista = query.getResultList();
            // commit transaction
            tx.commit();
        }
        Usuario result = new Usuario();
        for(Object[] obj : lista){
            result.setNombre("" + obj[9]);
        }
        return result ;
    }
}