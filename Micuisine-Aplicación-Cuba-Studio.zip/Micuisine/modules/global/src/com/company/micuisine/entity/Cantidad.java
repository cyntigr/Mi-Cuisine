package com.company.micuisine.entity;

import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.StandardEntity;

import javax.persistence.*;
import java.util.List;

@NamePattern("%s|peso")
@Table(name = "MICUISINE_CANTIDAD")
@Entity(name = "micuisine_Cantidad")
public class Cantidad extends StandardEntity {

    @Column(name = "PESO")
    protected String peso;
    @JoinTable(name = "MICUISINE_RECETA_CANTIDAD_LINK",
            joinColumns = @JoinColumn(name = "CANTIDAD_ID"),
            inverseJoinColumns = @JoinColumn(name = "RECETA_ID"))
    @ManyToMany
    protected List<Receta> recetas;

    public List<Receta> getRecetas() {
        return recetas;
    }

    public void setRecetas(List<Receta> recetas) {
        this.recetas = recetas;
    }

    public String getPeso() {
        return peso;
    }

    public void setPeso(String peso) {
        this.peso = peso;
    }
}