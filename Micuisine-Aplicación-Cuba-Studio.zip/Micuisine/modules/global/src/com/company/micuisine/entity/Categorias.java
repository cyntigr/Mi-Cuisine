package com.company.micuisine.entity;

import com.haulmont.chile.core.datatypes.impl.EnumClass;

import javax.annotation.Nullable;


public enum Categorias implements EnumClass<Integer> {

    Entrantes(1),
    Sopa(2),
    Verdura(3),
    Ensaladas(4),
    Arroz(5),
    Pasta(6),
    Pescado(7),
    Marisco(8),
    Pollo(9),
    Cerdo(10),
    Ternera(11),
    Postres(12);

    private Integer id;

    Categorias(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static Categorias fromId(Integer id) {
        for (Categorias at : Categorias.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}