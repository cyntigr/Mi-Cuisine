package com.company.micuisine.entity;

import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.StandardEntity;

import javax.persistence.*;
import java.util.List;

@NamePattern("%s|nombre")
@Table(name = "MICUISINE_INGREDIENTE")
@Entity(name = "micuisine_Ingrediente")
public class Ingrediente extends StandardEntity {
    @Column(name = "NOMBRE")
    protected String nombre;
    @JoinTable(name = "MICUISINE_RECETA_INGREDIENTE_LINK",
            joinColumns = @JoinColumn(name = "INGREDIENTE_ID"),
            inverseJoinColumns = @JoinColumn(name = "RECETA_ID"))
    @ManyToMany
    protected List<Receta> recetas;

    public List<Receta> getRecetas() {
        return recetas;
    }

    public void setRecetas(List<Receta> recetas) {
        this.recetas = recetas;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}