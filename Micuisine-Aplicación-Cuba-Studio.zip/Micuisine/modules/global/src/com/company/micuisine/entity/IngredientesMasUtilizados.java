package com.company.micuisine.entity;

import com.haulmont.cuba.core.entity.BaseUuidEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Table(name = "MICUISINE_INGREDIENTES_MAS_UTILIZADOS")
@Entity(name = "micuisine_IngredientesMasUtilizados")
public class IngredientesMasUtilizados extends BaseUuidEntity {
    @Column(name = "INGREDIENTE")
    protected String ingrediente;

    @Column(name = "CANTIDAD")
    protected Integer cantidad;

    public Integer getCantidad() {
        return cantidad;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }

    public String getIngrediente() {
        return ingrediente;
    }

    public void setIngrediente(String ingrediente) {
        this.ingrediente = ingrediente;
    }
}