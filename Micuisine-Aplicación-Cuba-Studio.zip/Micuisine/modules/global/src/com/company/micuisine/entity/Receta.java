package com.company.micuisine.entity;

import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.StandardEntity;
import com.haulmont.cuba.core.entity.annotation.OnDelete;
import com.haulmont.cuba.core.global.DeletePolicy;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@NamePattern("%s %s|nombre,id")
@Table(name = "MICUISINE_RECETA")
@Entity(name = "micuisine_Receta")
public class Receta extends StandardEntity {
    @Column(name = "CATEGORIA")
    protected Integer categoria;

    @Column(name = "NOMBRE")
    protected String nombre;

    @Column(name = "PERSONAS")
    protected String personas;

    @Column(name = "DURACION")
    protected String duracion;

    @Column(name = "PREPARACION")
    protected String preparacion;

    @Column(name = "VISITAS")
    protected Integer visitas;

    @Column(name = "CONSEJOS")
    protected String consejos;

    @Column(name = "URI")
    protected String uri;

    @Temporal(TemporalType.DATE)
    @Column(name = "FECHA_CREACION")
    protected Date fechaCreacion;

    @OnDelete(DeletePolicy.CASCADE)
    @JoinTable(name = "MICUISINE_RECETA_INGREDIENTE_LINK", joinColumns = @JoinColumn(name = "RECETA_ID"), inverseJoinColumns = @JoinColumn(name = "INGREDIENTE_ID"))
    @ManyToMany
    protected List<Ingrediente> listaIngredientes;

    @JoinTable(name = "MICUISINE_RECETA_CANTIDAD_LINK",
            joinColumns = @JoinColumn(name = "RECETA_ID"),
            inverseJoinColumns = @JoinColumn(name = "CANTIDAD_ID"))
    @ManyToMany
    protected List<Cantidad> listaCantidad;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(DeletePolicy.CASCADE)
    @JoinColumn(name = "USUARIO_ID")
    protected Usuario usuario;

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public List<Cantidad> getListaCantidad() {
        return listaCantidad;
    }

    public void setListaCantidad(List<Cantidad> listaCantidad) {
        this.listaCantidad = listaCantidad;
    }

    public void setCategoria(Categorias categoria) {
        this.categoria = categoria == null ? null : categoria.getId();
    }

    public Categorias getCategoria() {
        return categoria == null ? null : Categorias.fromId(categoria);
    }

    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public String getConsejos() {
        return consejos;
    }

    public void setConsejos(String consejos) {
        this.consejos = consejos;
    }

    public Integer getVisitas() {
        return visitas;
    }

    public void setVisitas(Integer visitas) {
        this.visitas = visitas;
    }

    public String getPreparacion() {
        return preparacion;
    }

    public void setPreparacion(String preparacion) {
        this.preparacion = preparacion;
    }

    public String getDuracion() {
        return duracion;
    }

    public void setDuracion(String duracion) {
        this.duracion = duracion;
    }

    public String getPersonas() {
        return personas;
    }

    public void setPersonas(String personas) {
        this.personas = personas;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setListaIngredientes(List<Ingrediente> listaIngredientes) {
        this.listaIngredientes = listaIngredientes;
    }

    public List<Ingrediente> getListaIngredientes() {
        return listaIngredientes;
    }

}