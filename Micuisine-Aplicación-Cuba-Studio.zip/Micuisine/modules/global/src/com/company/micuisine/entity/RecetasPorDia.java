package com.company.micuisine.entity;

import com.haulmont.cuba.core.entity.BaseUuidEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Table(name = "MICUISINE_RECETAS_POR_DIA")
@Entity(name = "micuisine_RecetasPorDia")
public class RecetasPorDia extends BaseUuidEntity {
    @Column(name = "FECHA")
    protected String fecha;

    @Column(name = "CANTIDAD_RECETAS")
    protected Integer cantidadRecetas;

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getFecha() {
        return fecha;
    }

    public Integer getCantidadRecetas() {
        return cantidadRecetas;
    }

    public void setCantidadRecetas(Integer cantidadRecetas) {
        this.cantidadRecetas = cantidadRecetas;
    }

}