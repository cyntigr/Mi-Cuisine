package com.company.micuisine.entity;

import com.haulmont.cuba.core.entity.BaseUuidEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Table(name = "MICUISINE_RECETAS_POR_USUARIO")
@Entity(name = "micuisine_RecetasPorUsuario")
public class RecetasPorUsuario extends BaseUuidEntity {
    @Column(name = "USUARIO")
    protected String usuario;

    @Column(name = "CANTIDAD_RECETAS")
    protected Integer cantidadRecetas;

    public void setCantidadRecetas(Integer cantidadRecetas) {
        this.cantidadRecetas = cantidadRecetas;
    }

    public Integer getCantidadRecetas() {
        return cantidadRecetas;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
}