package com.company.micuisine.entity;

import com.haulmont.chile.core.annotations.Composition;
import com.haulmont.chile.core.annotations.NamePattern;
import com.haulmont.cuba.core.entity.StandardEntity;
import com.haulmont.cuba.core.entity.annotation.OnDelete;
import com.haulmont.cuba.core.global.DeletePolicy;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.List;

@NamePattern("%s|id")
@Table(name = "MICUISINE_USUARIO")
@Entity(name = "micuisine_Usuario")
public class Usuario extends StandardEntity {

    @Column(name = "NOMBRE")
    protected String nombre;

    @Column(name = "APELLIDOS")
    protected String apellidos;

    @Column(name = "EMAIL")
    protected String email;

    @Column(name = "TELEFONO")
    protected String telefono;

    @Composition
    @OnDelete(DeletePolicy.CASCADE)
    @OneToMany(mappedBy = "usuario")
    protected List<Receta> lista;

    public List<Receta> getLista() {
        return lista;
    }

    public void setLista(List<Receta> lista) {
        this.lista = lista;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

}