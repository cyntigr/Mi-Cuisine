package com.company.micuisine.service;

import com.company.micuisine.entity.RecetasPorDia;
import com.company.micuisine.entity.RecetasPorUsuario;
import com.company.micuisine.entity.Usuario;

import java.util.Date;
import java.util.List;
import java.util.UUID;

public interface ConsultaDatosService {
    String NAME = "micuisine_ConsultaDatosService";

    List<RecetasPorDia> traerRecetasPorDia();

    List<RecetasPorUsuario> traerRecetasUsuario();

    Usuario traerUsuario(String id);
}