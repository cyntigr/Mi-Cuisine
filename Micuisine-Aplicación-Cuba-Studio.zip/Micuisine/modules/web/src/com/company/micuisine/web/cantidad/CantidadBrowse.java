package com.company.micuisine.web.cantidad;

import com.haulmont.cuba.gui.screen.*;
import com.company.micuisine.entity.Cantidad;

@UiController("micuisine_Cantidad.browse")
@UiDescriptor("cantidad-browse.xml")
@LookupComponent("cantidadsTable")
@LoadDataBeforeShow
public class CantidadBrowse extends StandardLookup<Cantidad> {
}