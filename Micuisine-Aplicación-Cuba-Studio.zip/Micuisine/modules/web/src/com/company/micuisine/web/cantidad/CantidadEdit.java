package com.company.micuisine.web.cantidad;

import com.haulmont.cuba.gui.screen.*;
import com.company.micuisine.entity.Cantidad;

@UiController("micuisine_Cantidad.edit")
@UiDescriptor("cantidad-edit.xml")
@EditedEntityContainer("cantidadDc")
@LoadDataBeforeShow
public class CantidadEdit extends StandardEditor<Cantidad> {
}