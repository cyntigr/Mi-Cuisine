package com.company.micuisine.web.ingrediente;

import com.haulmont.cuba.gui.screen.*;
import com.company.micuisine.entity.Ingrediente;

@UiController("micuisine_Ingrediente.browse")
@UiDescriptor("ingrediente-browse.xml")
@LookupComponent("ingredientesTable")
@LoadDataBeforeShow
public class IngredienteBrowse extends StandardLookup<Ingrediente> {
}