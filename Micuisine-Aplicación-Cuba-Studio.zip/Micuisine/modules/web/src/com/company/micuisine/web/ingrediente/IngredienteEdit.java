package com.company.micuisine.web.ingrediente;

import com.haulmont.cuba.gui.screen.*;
import com.company.micuisine.entity.Ingrediente;

@UiController("micuisine_Ingrediente.edit")
@UiDescriptor("ingrediente-edit.xml")
@EditedEntityContainer("ingredienteDc")
@LoadDataBeforeShow
public class IngredienteEdit extends StandardEditor<Ingrediente> {
}