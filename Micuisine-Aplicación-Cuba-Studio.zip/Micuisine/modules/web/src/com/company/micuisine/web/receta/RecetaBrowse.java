package com.company.micuisine.web.receta;

import com.company.micuisine.entity.RecetasPorDia;
import com.company.micuisine.service.ConsultaDatosService;
import com.haulmont.cuba.gui.model.CollectionContainer;
import com.haulmont.cuba.gui.screen.*;
import com.company.micuisine.entity.Receta;

import javax.inject.Inject;
import java.util.List;

@UiController("micuisine_Receta.browse")
@UiDescriptor("receta-browse.xml")
@LookupComponent("recetasTable")
@LoadDataBeforeShow
public class RecetaBrowse extends StandardLookup<Receta> {
    @Inject
    private CollectionContainer<RecetasPorDia> recetasPorDia;
    @Inject
    private ConsultaDatosService consultaDatosService;

    @Subscribe
    private void onAfterInit(AfterInitEvent event) {

        List<RecetasPorDia> recetasDia = consultaDatosService.traerRecetasPorDia();
        recetasPorDia.setItems(recetasDia);
    }
}