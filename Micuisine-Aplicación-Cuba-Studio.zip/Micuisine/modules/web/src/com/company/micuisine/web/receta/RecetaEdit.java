package com.company.micuisine.web.receta;

import com.company.micuisine.entity.Categorias;
import com.company.micuisine.entity.Usuario;
import com.haulmont.cuba.gui.components.*;
import com.haulmont.cuba.gui.screen.*;
import com.company.micuisine.entity.Receta;

import javax.inject.Inject;
import java.util.Date;

@UiController("micuisine_Receta.edit")
@UiDescriptor("receta-edit.xml")
@EditedEntityContainer("recetaDc")
@LoadDataBeforeShow
public class RecetaEdit extends StandardEditor<Receta> {
    @Inject
    private LookupField<Categorias> categoriaField;
    @Inject
    private TextField<String> consejosField;
    @Inject
    private TextField<String> duracionField;
    @Inject
    private DateField<Date> fechaCreacionField;
    @Inject
    private TextField<String> nombreField;
    @Inject
    private TextField<String> personasField;
    @Inject
    private TextField<String> preparacionField;
    @Inject
    private TextField<String> uriField;
    @Inject
    private PickerField<Usuario> usuario;
    @Inject
    private TextField<Integer> visitasField;
    @Inject
    private ButtonsPanel buttonsPanel;
    @Inject
    private ButtonsPanel buttonsPanel_1;

    @Subscribe
    private void onInitEntity(InitEntityEvent<Receta> event) {
        categoriaField.setEditable(true);
        nombreField.setEditable(true);
        personasField.setEditable(true);
        duracionField.setEditable(true);
        preparacionField.setEditable(true);
        visitasField.setEditable(true);
        consejosField.setEditable(true);
        uriField.setEditable(true);
        fechaCreacionField.setEditable(true);
        usuario.setEditable(true);
        buttonsPanel.setVisible(true);
        buttonsPanel_1.setVisible(true);
    }
}