package com.company.micuisine.web.usuario;

import com.company.micuisine.entity.RecetasPorUsuario;
import com.company.micuisine.service.ConsultaDatosService;
import com.haulmont.cuba.gui.model.CollectionContainer;
import com.haulmont.cuba.gui.screen.*;
import com.company.micuisine.entity.Usuario;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@UiController("micuisine_Usuario.browse")
@UiDescriptor("usuario-browse.xml")
@LookupComponent("usuariosTable")
@LoadDataBeforeShow
public class UsuarioBrowse extends StandardLookup<Usuario> {

    @Inject
    private ConsultaDatosService consultaDatosService;

    @Inject
    private CollectionContainer<Usuario> usuariosDc;
    @Inject
    private CollectionContainer<RecetasPorUsuario> recetasPorUsuariosDc;
    private List<RecetasPorUsuario> recetasUsuario = new ArrayList<>();
    private List<RecetasPorUsuario> recetasUsuarioNombre = new ArrayList<>();



    @Subscribe
    private void onAfterInit(AfterInitEvent event) {
        recetasUsuario.addAll(consultaDatosService.traerRecetasUsuario());

        for (RecetasPorUsuario cantidad : recetasUsuario){
            Usuario user = consultaDatosService.traerUsuario(cantidad.getUsuario());
            RecetasPorUsuario recetasUsuario = new RecetasPorUsuario();
            recetasUsuario.setCantidadRecetas(cantidad.getCantidadRecetas());
            recetasUsuario.setUsuario(user.getNombre());
            recetasUsuarioNombre.add(recetasUsuario);
        }
        recetasPorUsuariosDc.setItems(recetasUsuarioNombre);
    }
}