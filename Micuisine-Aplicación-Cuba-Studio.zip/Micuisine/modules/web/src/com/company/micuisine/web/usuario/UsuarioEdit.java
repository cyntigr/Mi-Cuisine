package com.company.micuisine.web.usuario;

import com.haulmont.cuba.gui.components.TextField;
import com.haulmont.cuba.gui.screen.*;
import com.company.micuisine.entity.Usuario;

import javax.inject.Inject;

@UiController("micuisine_Usuario.edit")
@UiDescriptor("usuario-edit.xml")
@EditedEntityContainer("usuarioDc")
@LoadDataBeforeShow
public class UsuarioEdit extends StandardEditor<Usuario> {

    @Inject
    private TextField<String> nombreField;
    @Inject
    private TextField<String> telefonoField;
    @Inject
    private TextField<String> emailField;
    @Inject
    private TextField<String> apellidosField;

    @Subscribe
    private void onInitEntity(InitEntityEvent<Usuario> event) {
        nombreField.setEditable(true);
        telefonoField.setEditable(true);
        emailField.setEditable(true);
        apellidosField.setEditable(true);
    }


}